$(function() {
  'use strict';

  /*simplemde editor*/
  if ($("#simpleMde1").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde1")[0]
    });
  }

    if ($("#simpleMde2").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde2")[0]
    });
  }


    if ($("#simpleMde3").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde3")[0]
    });
  }

      if ($("#simpleMde4").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde4")[0]
    });
  }

      if ($("#simpleMde5").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde5")[0]
    });
  }

      if ($("#simpleMde6").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde6")[0]
    });
  }

        if ($("#simpleMde7").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde7")[0]
    });
  }

        if ($("#simpleMde8").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde8")[0]
    });
  }

        if ($("#simpleMde9").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde9")[0]
    });
  }

        if ($("#simpleMde10").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde10")[0]
    });
  }

        if ($("#simpleMde11").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde11")[0]
    });
  }

        if ($("#simpleMde12").length) {
    var simplemde = new SimpleMDE({
      element: $("#simpleMde12")[0]
    });
  }


});