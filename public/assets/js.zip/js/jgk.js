$(document).ready(function(){
    // alert('asd');
    // $('.synk_shopify_order').on('click',function(){
    //     var url = $(this).data('url');
    //     $.ajax({
    //         type : 'GET',
    //         url : url,
    //         success: function(result) {
    //             centeredPopup(result.url,'myWindow','700','300','yes');
    //         }
    //     });
    //     return false;
    // });

    // function centeredPopup(url,winName,w,h,scroll){
    //     LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
    //     TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
    //     settings =
    //     'height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroll+',resizable'
    //     popupWindow = window.open(url,winName,settings)
    // }
})